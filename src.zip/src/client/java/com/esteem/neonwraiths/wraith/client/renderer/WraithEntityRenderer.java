package com.esteem.neonwraiths.wraith.client.renderer;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.EquipmentModelData;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.util.Identifier;

public class WraithEntityRenderer extends
        BipedEntityRenderer<
                WraithBot,
                WraithEntityRenderer.WraithRenderState, // 💥 CHANGED: Custom State Pass Kiya
                BipedEntityModel<WraithEntityRenderer.WraithRenderState> // 💥 CHANGED: Model ko bhi bataya
                > {

    // =========================================
    // 💥 1. CUSTOM RENDER STATE (Skin yaad rakhne ke liye)
    // =========================================
    public static class WraithRenderState extends BipedEntityRenderState {
        public Identifier customSkin;
    }

    // =========================================
    // 💥 2. NEW DEFAULT SKINS ARRAY (Wide Models)
    // =========================================
    private static final Identifier[] SKINS = new Identifier[]{
            Identifier.of("minecraft", "textures/entity/player/wide/steve.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/alex.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/ari.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/efe.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/kai.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/makena.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/noor.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/sunny.png"),
            Identifier.of("minecraft", "textures/entity/player/wide/zuri.png")
    };

    public WraithEntityRenderer(
            EntityRendererFactory.Context context
    ) {
        super(
                context,
                new BipedEntityModel<>(
                        context.getPart(
                                EntityModelLayers.PLAYER
                        )
                ),
                0.5f
        );

        // ✅ HELD ITEM (Weapons & Shield)
        this.addFeature(
                new HeldItemFeatureRenderer<>(this)
        );

        // ✅ FINAL ARMOR FIX
        this.addFeature(new ArmorFeatureRenderer<>(
                this,
                EquipmentModelData.mapToEntityModel(
                        EntityModelLayers.PLAYER_EQUIPMENT,
                        context.getEntityModels(),
                        (modelPart) -> new BipedEntityModel<>(modelPart)
                ),
                context.getEquipmentRenderer()
        ));
    }

    // =========================================
    // 💥 3. RENDER METHODS UPDATED
    // =========================================

    @Override
    public Identifier getTexture(
            WraithRenderState state // 💥 CHANGED: State use karega
    ) {
        // Yahan memory se skin return karega
        return state.customSkin != null ? state.customSkin : SKINS[0];
    }

    @Override
    public WraithRenderState createRenderState() {
        // 💥 CHANGED: Naya custom state banayega
        return new WraithRenderState();
    }

    @Override
    public void updateRenderState(
            WraithBot entity,
            WraithRenderState state, // 💥 CHANGED: Custom state
            float tickDelta
    ) {
        super.updateRenderState(
                entity,
                state,
                tickDelta
        );

        // 💥 CALCULATE SKIN: Game tick hote hi skin assign kardo ID ke basis par
        int skinIndex = Math.abs(entity.getId()) % SKINS.length;
        state.customSkin = SKINS[skinIndex];
    }
}