package com.esteem.neonwraiths;

import com.esteem.neonwraiths.wraith.client.renderer.WraithEntityRenderer;
import com.esteem.neonwraiths.wraith.entities.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NeonWraithsClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        NeonWraiths.LOGGER.info("Neon Wraiths Client-Side loaded! Ready for custom visuals.");

        // Game engine ko bol rahe hain: "wraith_bot ko paint karne ke liye WraithEntityRenderer use karo"
        EntityRendererRegistry.register(ModEntities.WRAITH_BOT, WraithEntityRenderer::new);
    }
}