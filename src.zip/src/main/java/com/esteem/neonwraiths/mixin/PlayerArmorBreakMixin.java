package com.esteem.neonwraiths.mixin;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerArmorBreakMixin {

    // Hum Player ke damage function ko bilkul start (HEAD) me intercept kar rahe hain
    @Inject(method = "damage", at = @At("HEAD"))
    private void onWraithBotHit(ServerWorld world, DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {

        // Check karo ki maarne wala hamara WraithBot hi hai na?
        if (source.getAttacker() instanceof WraithBot) {
            PlayerEntity targetPlayer = (PlayerEntity) (Object) this;

            // 💥 FIX 1: Agar player Creative ya Spectator me hai, toh armor ko kuch mat karo
            if (targetPlayer.isCreative() || targetPlayer.isSpectator()) {
                return;
            }

            // 💥 FIX 2: Armor Break Speed (Maine 2 rakhi hai, agar aur slow chahiye toh 1 kar dena)
            int durabilityDamage = 2;

            EquipmentSlot[] armorSlots = {
                    EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                    EquipmentSlot.LEGS, EquipmentSlot.FEET
            };

            boolean armorChanged = false;

            // Player ka armor fodo but rules ke sath
            for (EquipmentSlot slot : armorSlots) {
                ItemStack armorPiece = targetPlayer.getEquippedStack(slot);

                if (!armorPiece.isEmpty() && armorPiece.isDamageable()) {
                    if (targetPlayer instanceof ServerPlayerEntity serverPlayer) {

                        // 💥 FIX 3: UNBREAKING RESPECT!
                        // Vanilla Minecraft ka 'damage' function use kiya hai.
                        // Ye automatically Unbreaking enchant check karega aur tootne ki sound bhi khud play karega.
                        armorPiece.damage(durabilityDamage, world, serverPlayer, item -> {
                            targetPlayer.sendEquipmentBreakStatus(item, slot);
                        });

                        armorChanged = true;
                    }
                }
            }

            // UI (Screen) par player ko dikhao ki armor update hua hai
            if (armorChanged && targetPlayer instanceof ServerPlayerEntity serverPlayer) {
                serverPlayer.currentScreenHandler.sendContentUpdates();
            }
        }
    }
}