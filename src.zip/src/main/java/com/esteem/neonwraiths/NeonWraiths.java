package com.esteem.neonwraiths;

// 💥 FIX: Teeno nayi command classes import ki hain
import com.esteem.neonwraiths.wraith.commands.*;
import com.esteem.neonwraiths.wraith.entities.ModEntities;
import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback; // 💥 FIX: Fabric command API import
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NeonWraiths implements ModInitializer {

    public static final String MOD_ID = "neonwraiths";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Neon Wraiths AI Framework for 1.21.11...");
         WraithCommand.register();
        ModEntities.registerModEntities();

        FabricDefaultAttributeRegistry.register(ModEntities.WRAITH_BOT, WraithBot.createWraithAttributes());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            LtCommand.register(dispatcher); // LOW Tier
            HtCommand.register(dispatcher); // HIGH Tier
            MtCommand.register(dispatcher); // MASTER Tier
            SoloCommand.register(dispatcher); // MT+SOLO Tier
            WraithTeleportCommand.register(dispatcher);
            tiercustomcom.register(dispatcher);
        });
    }
}