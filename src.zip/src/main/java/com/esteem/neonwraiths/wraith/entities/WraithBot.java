package com.esteem.neonwraiths.wraith.entities;

import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.entity.FakePlayer;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;

import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import net.minecraft.sound.SoundEvents;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.player.PlayerEntity;
import com.esteem.neonwraiths.wraith.ai.goals.WraithBrainGoal;
import com.esteem.neonwraiths.wraith.combat.nethpot.NethpotBrain;
import com.esteem.neonwraiths.wraith.combat.tank.TankBrain;
import com.esteem.neonwraiths.wraith.utils.FormationManager;
import org.jetbrains.annotations.Nullable;

public class WraithBot extends HostileEntity {

    public enum Tier { LOW, HIGH, MASTER, SOLO }
    public enum BotMode { IDLE, ATTACK, FOLLOW, FORMATION, STOP }

    private BotMode currentMode = BotMode.IDLE;
    private PlayerEntity commandOwner = null;
    private int formationIndex = 0;
    private int totalFormationBots = 1;
    private String currentFormationType = "circle";

    private WraithBrainGoal currentCombatGoal;
    private float lockedFormationYaw = 0.0F;

    private Tier tier = Tier.LOW;
    private String currentPvpMode = "nethpot"; // Default
    private net.minecraft.entity.LivingEntity customAttackTarget = null;
    private final World botWorld;
    private boolean hasAddedToTab = false;
    private boolean memoryLoaded = false;

    private final SimpleInventory inventory = new SimpleInventory(36);
    private final Random rand = new Random();

    public static final String[] SUPPORTED_PVP_MODES = {"nethpot", "tank", "axe", "crystal", "anchor"};

    public WraithBot(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.botWorld = world;

        // Bot pani ko avoid nahi karega, andar aayega
        this.setPathfindingPenalty(net.minecraft.entity.ai.pathing.PathNodeType.WATER, 0.0F);
    }

    public static DefaultAttributeContainer.Builder createWraithAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 20.0D)
                // 💥 SPEED FIX: 0.35D se 0.28D kar diya, ab movement ekdum normal player jaisi lagegi!
                .add(EntityAttributes.MOVEMENT_SPEED, 0.28D)
                .add(EntityAttributes.ATTACK_DAMAGE, 3.0D)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.0D);
    }

    @Override
    protected void initGoals() {
        super.initGoals();

        // SwimGoal hata diya hai, ab custom logic se tairega

        this.currentCombatGoal = new WraithBrainGoal(this, 1.2D, false, new NethpotBrain(this));
        this.goalSelector.add(2, this.currentCombatGoal);

        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(4, new LookAroundGoal(this));
    }

    public void setPvpBrain(String pvpMode) {
        if (this.currentCombatGoal != null) {
            this.goalSelector.remove(this.currentCombatGoal);
        }

        this.currentPvpMode = pvpMode.toLowerCase();

        com.esteem.neonwraiths.wraith.combat.CombatBrain newBrain;

        switch (this.currentPvpMode) {
            case "tank":
                newBrain = new TankBrain(this);
                break;
            case "axe":
            case "crystal":
            case "anchor":
                newBrain = new NethpotBrain(this);
                break;
            case "nethpot":
            default:
                newBrain = new NethpotBrain(this);
                break;
        }

        this.currentCombatGoal = new WraithBrainGoal(this, 1.2D, false, newBrain);
        this.goalSelector.add(2, this.currentCombatGoal);

        updateMemoryTags();
    }

    @Override
    public void setTarget(@Nullable net.minecraft.entity.LivingEntity target) {
        super.setTarget(target);
        this.customAttackTarget = target;
    }

    public void setTier(Tier tier) {
        this.tier = tier;
        updateMemoryTags();
    }

    public void setBotMode(BotMode mode, PlayerEntity owner, int index, int totalBots, String formType) {
        this.getNavigation().stop();
        this.setTarget(null);
        this.setAttacker(null);

        this.currentMode = mode;
        this.commandOwner = owner;
        this.formationIndex = index;
        this.totalFormationBots = totalBots;

        if (formType != null && !formType.isEmpty()) {
            this.currentFormationType = formType.toLowerCase();
        }
        if (owner != null) {
            this.lockedFormationYaw = owner.getYaw();
        }
        updateMemoryTags();
    }

    private void updateMemoryTags() {
        for (Tier t : Tier.values()) this.removeCommandTag("WRAITH_TIER_" + t.name());
        for (BotMode m : BotMode.values()) this.removeCommandTag("WRAITH_MODE_" + m.name());

        for (String mode : SUPPORTED_PVP_MODES) {
            this.removeCommandTag("WRAITH_PVP_" + mode.toUpperCase());
        }

        this.addCommandTag("WRAITH_TIER_" + this.tier.name());
        this.addCommandTag("WRAITH_MODE_" + this.currentMode.name());
        this.addCommandTag("WRAITH_PVP_" + this.currentPvpMode.toUpperCase());
    }

    public BotMode getCurrentMode() { return this.currentMode; }
    public PlayerEntity getCommandOwner() { return this.commandOwner; }
    public SimpleInventory getInventory() { return this.inventory; }
    public Tier getTier() { return this.tier; }
    public net.minecraft.entity.LivingEntity getCustomTarget() { return this.customAttackTarget; }

    @Override
    public boolean cannotDespawn() {
        return true;
    }

    @Override
    protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        operateMasterBrain(world);
    }

    private void operateMasterBrain(ServerWorld world) {
        if (this.currentMode == BotMode.ATTACK) {
            if (this.getTarget() == null || !this.getTarget().isAlive()) {
                if (this.age % 10 == 0) {
                    List<PlayerEntity> enemies = world.getEntitiesByClass(
                            PlayerEntity.class,
                            this.getBoundingBox().expand(150.0D),
                            e -> e != this.commandOwner && e.isAlive() && !e.isSpectator() && !e.isCreative()
                    );
                    if (!enemies.isEmpty()) {
                        if (this.customAttackTarget != null && this.customAttackTarget.isAlive() && this.customAttackTarget instanceof PlayerEntity && this.customAttackTarget != this.commandOwner) {
                            this.setTarget(this.customAttackTarget);
                        } else {
                            this.setTarget(enemies.get(0));
                        }
                    } else {
                        this.setTarget(null);
                    }
                }
            }
            return;
        }

        if (this.getTarget() != null) this.setTarget(null);

        if (this.currentMode == BotMode.STOP) {
            this.getNavigation().stop();
        }
        else if (this.currentMode == BotMode.IDLE) {
            if (this.getNavigation().isIdle() && this.rand.nextInt(40) == 0) {
                double rx = this.getX() + (this.rand.nextDouble() - 0.5D) * 12.0D;
                double rz = this.getZ() + (this.rand.nextDouble() - 0.5D) * 12.0D;
                this.getNavigation().startMovingTo(rx, this.getY(), rz, 1.0D);
            }
        }
        else if (this.currentMode == BotMode.FOLLOW && this.commandOwner != null) {
            this.getLookControl().lookAt(this.commandOwner, 30.0F, 30.0F);
            double dist = this.squaredDistanceTo(this.commandOwner);
            if (dist > 16.0D) {
                if (this.age % 5 == 0) this.getNavigation().startMovingTo(this.commandOwner, 1.3D);
            } else if (dist < 6.25D) {
                this.getNavigation().stop();
            }
        }
        else if (this.currentMode == BotMode.FORMATION && this.commandOwner != null) {
            this.getLookControl().lookAt(this.commandOwner, 30.0F, 30.0F);

            int total = Math.max(1, this.totalFormationBots);

            net.minecraft.util.math.Vec3d ownerPos = new net.minecraft.util.math.Vec3d(
                    this.commandOwner.getX(),
                    this.commandOwner.getY(),
                    this.commandOwner.getZ()
            );

            List<net.minecraft.util.math.Vec3d> positions = FormationManager.generate(
                    this.currentFormationType,
                    total,
                    ownerPos,
                    this.lockedFormationYaw
            );

            if (this.formationIndex >= 0 && this.formationIndex < positions.size()) {
                net.minecraft.util.math.Vec3d targetPos = positions.get(this.formationIndex);

                if (this.squaredDistanceTo(targetPos.x, targetPos.y, targetPos.z) > 2.0D) {
                    if (this.age % 5 == 0) this.getNavigation().startMovingTo(targetPos.x, targetPos.y, targetPos.z, 1.3D);
                } else {
                    this.getNavigation().stop();
                }
            }
        }
    }

    @Override
    public void tickMovement() {
        if (!this.botWorld.isClient()) {
            if (this.currentMode == BotMode.STOP) {
                this.setVelocity(0, this.getVelocity().y, 0);
                this.setJumping(false);
            }

            // 💥 SMART WATER CHASE AI: Agar bot pani me hai aur player bhi pani me hai
            if (this.isTouchingWater() && this.getTarget() != null) {
                // Agar player bot ki current height se thoda bhi upar hai, toh bot tairte hue upar aayega
                if (this.getTarget().getY() > this.getY() + 0.3D) {
                    this.getJumpControl().setActive();
                }
            }
        }
        super.tickMovement();
    }

    @Override
    public boolean damage(ServerWorld world, DamageSource source, float amount) {
        if (this.currentMode != BotMode.ATTACK) {
            this.setTarget(null);
        }
        return super.damage(world, source, amount);
    }

    @Override
    public void tick() {
        super.tick();

        // 💥 FIX: Concurrent Modification Bypass
        if (!this.botWorld.isClient() && !this.memoryLoaded) {

            String loadedPvpMode = null;
            Tier loadedTier = null;
            BotMode loadedMode = null;

            for (String tag : this.getCommandTags()) {
                if (tag.startsWith("WRAITH_TIER_")) {
                    try { loadedTier = Tier.valueOf(tag.replace("WRAITH_TIER_", "")); } catch (Exception e) {}
                }
                if (tag.startsWith("WRAITH_MODE_")) {
                    try { loadedMode = BotMode.valueOf(tag.replace("WRAITH_MODE_", "")); } catch (Exception e) {}
                }
                if (tag.startsWith("WRAITH_PVP_")) {
                    loadedPvpMode = tag.replace("WRAITH_PVP_", "").toLowerCase();
                }
            }

            if (loadedTier != null) this.tier = loadedTier;
            if (loadedMode != null) this.currentMode = loadedMode;
            if (loadedPvpMode != null) {
                this.setPvpBrain(loadedPvpMode);
            }

            this.memoryLoaded = true;
        }

        if (!this.botWorld.isClient() && !this.hasAddedToTab) {
            this.addToTabList();
            this.hasAddedToTab = true;
        }
    }

    private void addToTabList() {
        if (this.botWorld.getServer() == null || !(this.botWorld instanceof ServerWorld serverWorld)) return;

        String realName = this.getName().getString();

        if (realName.length() > 16) {
            realName = realName.substring(0, 16);
        }

        GameProfile profile = new GameProfile(this.getUuid(), realName);
        ServerPlayerEntity fakePlayer = FakePlayer.get(serverWorld, profile);

        PlayerListS2CPacket packet = new PlayerListS2CPacket(
                EnumSet.of(PlayerListS2CPacket.Action.ADD_PLAYER, PlayerListS2CPacket.Action.UPDATE_LISTED),
                List.of(fakePlayer)
        );

        for (ServerPlayerEntity player : this.botWorld.getServer().getPlayerManager().getPlayerList()) {
            player.networkHandler.sendPacket(packet);
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!this.botWorld.isClient() && this.botWorld.getServer() != null) {
            PlayerRemoveS2CPacket packet = new PlayerRemoveS2CPacket(List.of(this.getUuid()));
            for (ServerPlayerEntity player : this.botWorld.getServer().getPlayerManager().getPlayerList()) {
                player.networkHandler.sendPacket(packet);
            }
        }
        super.remove(reason);
    }

    @Override
    protected void dropEquipment(ServerWorld world, DamageSource source, boolean causedByPlayer) {
        super.dropEquipment(world, source, causedByPlayer);

        for (net.minecraft.entity.EquipmentSlot slot : net.minecraft.entity.EquipmentSlot.values()) {
            ItemStack equippedStack = this.getEquippedStack(slot);
            if (!equippedStack.isEmpty()) {
                this.dropStack(world, equippedStack);
                this.equipStack(slot, ItemStack.EMPTY);
            }
        }

        for (int i = 0; i < this.inventory.size(); i++) {
            ItemStack stack = this.inventory.getStack(i);
            if (!stack.isEmpty()) {
                this.dropStack(world, stack);
            }
        }
    }

    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);
        if (!this.botWorld.isClient() && this.botWorld.getServer() != null) {
            Text deathMessage = damageSource.getDeathMessage(this);
            this.botWorld.getServer().getPlayerManager().broadcast(deathMessage, false);
            Text leftMessage = Text.translatable("multiplayer.player.left", this.getDisplayName()).formatted(Formatting.YELLOW);
            this.botWorld.getServer().getPlayerManager().broadcast(leftMessage, false);
        }
    }

    @Override
    public void damageArmor(DamageSource source, float amount) {
        if (amount <= 0.0F || source.isIn(net.minecraft.registry.tag.DamageTypeTags.BYPASSES_ARMOR)) return;
        int durabilityDamage = (int) Math.max(1.0F, amount / 4.0F);
        net.minecraft.entity.EquipmentSlot[] armorSlots = {
                net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST,
                net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET
        };
        for (net.minecraft.entity.EquipmentSlot slot : armorSlots) {
            ItemStack stack = this.getEquippedStack(slot);
            if (!stack.isEmpty() && stack.isDamageable()) {
                int currentDamage = stack.getDamage();
                int newDamage = currentDamage + durabilityDamage;
                if (newDamage >= stack.getMaxDamage()) {
                    this.playSound(SoundEvents.ENTITY_ITEM_BREAK.value(), 1.0F, 1.0F);
                    this.equipStack(slot, ItemStack.EMPTY);
                } else {
                    stack.setDamage(newDamage);
                }
            }
        }
    }

    // ==========================================
    // 💥 GLOBAL ARMOR BREAK & BYPASS FUNCTION
    // ==========================================
    public void applyBypassAndArmorDamage(net.minecraft.entity.LivingEntity target, float rawDamage) {
        if (!(this.getEntityWorld() instanceof net.minecraft.server.world.ServerWorld serverWorld)) return;

        float armor = target.getArmor();
        float toughness = (float) target.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.ARMOR_TOUGHNESS);

        float damageReduction = armor - (rawDamage * 4.0F) / (toughness + 8.0F);
        float clamp = Math.max(armor / 5.0F, Math.min(20.0F, damageReduction));
        float finalDamage = rawDamage * (1.0F - clamp / 25.0F);

        // Target ke I-Frames ko zabardasti 0 kar do
        target.timeUntilRegen = 0;

        target.damage(serverWorld, serverWorld.getDamageSources().mobAttack(this), finalDamage);
    }
}