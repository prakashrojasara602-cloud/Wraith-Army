package com.esteem.neonwraiths.wraith.entities;

import com.esteem.neonwraiths.NeonWraiths;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class ModEntities {

    // 💥 NAYA 1.21+ RULE: Pehle Entity ka ek RegistryKey banana padega
    public static final RegistryKey<EntityType<?>> WRAITH_BOT_KEY = RegistryKey.of(
            RegistryKeys.ENTITY_TYPE,
            Identifier.of(NeonWraiths.MOD_ID, "wraith_bot")
    );

    public static final EntityType<WraithBot> WRAITH_BOT = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(NeonWraiths.MOD_ID, "wraith_bot"),
            FabricEntityTypeBuilder.<WraithBot>create(SpawnGroup.MONSTER, WraithBot::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .build(WRAITH_BOT_KEY) // 💥 NAYA FIX: Yahan key pass ki gayi hai
    );

    public static void registerModEntities() {
        NeonWraiths.LOGGER.info("Registering Neon Wraith Entities...");
    }
}