package com.esteem.neonwraiths.wraith.combat.tank;

import com.esteem.neonwraiths.wraith.combat.CombatBrain;
import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

public class TankBrain implements CombatBrain {

    private final WraithBot bot;
    private int attackCooldown = 0;
    private int sprintResetTimer = 0;

    public TankBrain(WraithBot bot) {
        this.bot = bot;
    }

    @Override
    public void updateTactics(WraithBot bot, LivingEntity target) {
        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }

        // 💥 FIX: STRICT GROUNDING (No Jumps for Crits)
        // Agar bot dushman ke paas hai aur samne koi block (diwar) nahi hai, toh jump band kar do
        if (bot.squaredDistanceTo(target) < 25.0) {
            bot.setJumping(false);

            // Agar main goal file ne zabardasti isko hawa me uchhal diya hai, toh usko wapas zameen par kheencho
            if (bot.getVelocity().y > 0 && !bot.horizontalCollision) {
                bot.setVelocity(bot.getVelocity().x, -0.05, bot.getVelocity().z); // Jump cancel karke wapas niche laya
            }
        }

        // 🧠 PRO W-TAP SIMULATOR
        if (this.sprintResetTimer > 0) {
            this.sprintResetTimer--;
            bot.setSprinting(false);
        } else {
            bot.setSprinting(true);
        }

        ItemStack mainHandItem = bot.getMainHandStack();
        if (mainHandItem.getItem() != Items.DIAMOND_SWORD) {
            equipBestWeapon();
        }

        // 🚀 AGGRESSIVE GAP-CLOSING
        double distanceSq = bot.squaredDistanceTo(target);
        if (distanceSq < 20.0 && distanceSq > 2.25 && bot.isOnGround() && this.sprintResetTimer == 0) {
            Vec3d lookVec = bot.getRotationVec(1.0F).normalize().multiply(0.12);
            bot.addVelocity(lookVec.x, 0.0, lookVec.z);
        }
    }

    @Override
    public double getAttackRange() {
        return 8.0;
    }

    @Override
    public int getCooldownTicks() {
        return 11;
    }

    @Override
    public void executeAttack(WraithBot bot, LivingEntity target) {
        if (this.attackCooldown <= 0) {

            bot.swingHand(Hand.MAIN_HAND);

            if (bot.getEntityWorld() instanceof ServerWorld serverWorld) {

                // Pure Heavy Damage
                float realDamage = 24.0F;

                boolean hitLanded = target.damage(serverWorld, bot.getDamageSources().mobAttack(bot), realDamage);

                if (hitLanded) {
                    // Ground Knockback (W-Tap momentum)
                    double knockX = bot.getX() - target.getX();
                    double knockZ = bot.getZ() - target.getZ();

                    target.takeKnockback(0.60F, knockX, knockZ);

                    // Hit lagte hi W-Tap timer chaloo
                    this.sprintResetTimer = 2;
                }
            }

            this.attackCooldown = 11;
        }
    }

    private void equipBestWeapon() {
        for (int i = 0; i < bot.getInventory().size(); i++) {
            ItemStack stack = bot.getInventory().getStack(i);
            if (stack.getItem() == Items.DIAMOND_SWORD) {
                bot.equipStack(net.minecraft.entity.EquipmentSlot.MAINHAND, stack);
                break;
            }
        }
    }
}