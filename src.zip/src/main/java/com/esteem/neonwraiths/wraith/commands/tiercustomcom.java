package com.esteem.neonwraiths.wraith.commands;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import com.esteem.neonwraiths.wraith.entities.ModEntities; // Exact Path
import com.esteem.neonwraiths.wraith.utils.FormationManager;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class tiercustomcom  {

    // =========================================
    // 💥 AUTO-COMPLETE LISTS (ALL COMBINED)
    // =========================================
    private static final SuggestionProvider<ServerCommandSource> SUGGEST_TIERS = (context, builder) ->
            CommandSource.suggestMatching(List.of("lt", "ht", "mt", "solo"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_PVP = (context, builder) ->
            CommandSource.suggestMatching(List.of("tank", "axe", "nethpot", "crystal", "anchor"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_ARMOR = (context, builder) ->
            CommandSource.suggestMatching(List.of("diamond", "netherite"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_FORMATIONS = (context, builder) ->
            CommandSource.suggestMatching(List.of("line", "grid", "circle", "square", "spearhead", "wall", "random"), builder);

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("wraith")
                // OP CHECK (Works perfectly in 1.21)
                .requires(source -> net.minecraft.server.command.CommandManager.GAMEMASTERS_CHECK.allows(source.getPermissions()))

                // 🐣 THE ULTIMATE MASTER SPAWN COMMAND
                // Syntax: /wraith spawn <custom_name> <tier> <count> <pvp> <armor> <formation>
                .then(CommandManager.literal("spawn")
                        .then(CommandManager.argument("botName", StringArgumentType.word()) // 1. Custom Name
                                .then(CommandManager.argument("tier", StringArgumentType.word()).suggests(SUGGEST_TIERS) // 2. Tier Selection
                                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 100)) // 3. Amount
                                                .then(CommandManager.argument("pvp", StringArgumentType.word()).suggests(SUGGEST_PVP) // 4. PvP Mode
                                                        .then(CommandManager.argument("armor", StringArgumentType.word()).suggests(SUGGEST_ARMOR) // 5. Armor Type
                                                                .then(CommandManager.argument("formation", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS) // 6. Formation
                                                                        .executes(context -> {
                                                                            String botName = StringArgumentType.getString(context, "botName");
                                                                            String tierStr = StringArgumentType.getString(context, "tier");
                                                                            int count = IntegerArgumentType.getInteger(context, "count");
                                                                            String pvp = StringArgumentType.getString(context, "pvp");
                                                                            String armor = StringArgumentType.getString(context, "armor");
                                                                            String formation = StringArgumentType.getString(context, "formation");

                                                                            return spawnMasterBots(context.getSource(), botName, tierStr, count, pvp, armor, formation);
                                                                        })
                                                                )
                                                        )
                                                )
                                        )
                                )
                        )
                )

                .then(CommandManager.literal("attack")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMasterMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.ATTACK, "ATTACK", ""))
                        )
                )
                .then(CommandManager.literal("stop")
                        .executes(context -> executeMasterMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.STOP, "STOP", ""))
                )
                .then(CommandManager.literal("follow")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMasterMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.FOLLOW, "FOLLOW", ""))
                        )
                )
        );
    }

    private static int spawnMasterBots(ServerCommandSource source, String customName, String tierStr, int amount, String pvp, String armor, String formationType) {
        ServerWorld world = source.getWorld();
        ServerPlayerEntity player = source.getPlayer();

        if (player == null) return 0;

        float naturalYaw = player.getYaw();
        double spawnDistance = 6.0;
        double forwardX = -Math.sin(Math.toRadians(naturalYaw)) * spawnDistance;
        double forwardZ = Math.cos(Math.toRadians(naturalYaw)) * spawnDistance;

        Vec3d centerPos = new Vec3d(
                Math.floor(source.getPosition().x + forwardX) + 0.5,
                source.getPosition().y,
                Math.floor(source.getPosition().z + forwardZ) + 0.5
        );

        WraithBot.Tier selectedTier;
        switch (tierStr.toLowerCase()) {
            case "ht": selectedTier = WraithBot.Tier.HIGH; break;
            case "mt": selectedTier = WraithBot.Tier.MASTER; break;
            case "solo": selectedTier = WraithBot.Tier.SOLO; break;
            case "lt":
            default: selectedTier = WraithBot.Tier.LOW; break;
        }

        List<Vec3d> positions = FormationManager.generate(formationType, amount, centerPos, naturalYaw);

        for (int i = 0; i < amount; i++) {
            WraithBot bot = (WraithBot) ModEntities.WRAITH_BOT.create(world, net.minecraft.entity.SpawnReason.COMMAND);

            if (bot != null) {
                Vec3d targetPos = positions.get(i);
                double finalX = Math.floor(targetPos.x) + 0.5;
                double finalY = targetPos.y;
                double finalZ = Math.floor(targetPos.z) + 0.5;

                bot.refreshPositionAndAngles(finalX, finalY, finalZ, naturalYaw, 0.0F);
                bot.setHeadYaw(naturalYaw);
                bot.setBodyYaw(naturalYaw);

                String cleanName = customName.replace("_", " ");
                String finalName = amount > 1 ? cleanName + " " + (i + 1) : cleanName;

                String colorCode = "§a";
                if(selectedTier == WraithBot.Tier.HIGH);
                if(selectedTier == WraithBot.Tier.MASTER) ;
                if(selectedTier == WraithBot.Tier.SOLO) colorCode = "§d§l";

                bot.setCustomName(Text.literal(colorCode + finalName));
                bot.setCustomNameVisible(true);

                bot.setTier(selectedTier);
                com.esteem.neonwraiths.wraith.inventory.BotLoadout.equip(bot, pvp, armor);

                bot.setBotMode(WraithBot.BotMode.STOP, player, i, amount, formationType);

                world.spawnEntity(bot);
            }
        }

        source.sendFeedback(() -> Text.literal("§e[MASTER AI] Deployed " + amount + " " + tierStr.toUpperCase() + " Bots as '" + customName.replace("_", " ") + "'!"), false);
        return 1;
    }

    private static int executeMasterMode(ServerCommandSource source, ServerPlayerEntity targetPlayer, WraithBot.BotMode mode, String modeName, String formType) {
        if (targetPlayer == null) return 0;
        ServerPlayerEntity commander = source.getPlayer();
        if (commander == null) return 0;
        ServerWorld serverWorld = source.getWorld();

        Box radarBox = commander.getBoundingBox().expand(150.0D);

        List<WraithBot> botsNearby = serverWorld.getEntitiesByClass(WraithBot.class, radarBox, bot -> true);

        if (botsNearby.isEmpty()) {
            source.sendError(Text.literal("§c[MASTER AI] No bots found to command!"));
            return 0;
        }

        int totalBots = botsNearby.size();
        int index = 0;

        for (WraithBot bot : botsNearby) {
            if (mode == WraithBot.BotMode.ATTACK) {
                bot.setBotMode(mode, commander, index, totalBots, formType);
                bot.setTarget(targetPlayer);
            } else if (mode == WraithBot.BotMode.FOLLOW) {
                bot.setBotMode(mode, targetPlayer, index, totalBots, formType);
            } else {
                bot.setBotMode(mode, commander, index, totalBots, formType);
            }
            index++;
        }

        String targetName = targetPlayer.getName().getString();
        if (mode == WraithBot.BotMode.ATTACK || mode == WraithBot.BotMode.FOLLOW) {
            source.sendFeedback(() -> Text.literal("§e[MASTER AI] Commanded ALL " + totalBots + " bots to §l" + modeName + "§e on " + targetName + "!"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§e[MASTER AI] Commanded ALL " + totalBots + " bots to §l" + modeName + "!"), false);
        }
        return 1;
    }
}