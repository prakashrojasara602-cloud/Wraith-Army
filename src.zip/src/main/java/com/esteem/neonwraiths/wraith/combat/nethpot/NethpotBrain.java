package com.esteem.neonwraiths.wraith.combat.nethpot;

import com.esteem.neonwraiths.wraith.combat.CombatBrain;
import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;

public class NethpotBrain implements CombatBrain {

    private final WraithBot bot;
    private int attackDelay = 0;
    private int jumpDelay = 0;
    private int healCooldown = 0;

    public NethpotBrain(WraithBot bot) {
        this.bot = bot;
    }

    @Override
    public void updateTactics(WraithBot bot, LivingEntity target) {
        WraithBot.Tier tier = bot.getTier();

        if (this.attackDelay > 0) this.attackDelay--;
        if (this.jumpDelay > 0) this.jumpDelay--;
        if (this.healCooldown > 0) this.healCooldown--;

        float healthPercent = bot.getHealth() / bot.getMaxHealth();
        float healThreshold;
        int nextHealDelay;

        switch (tier) {
            case SOLO:
                healThreshold = 0.40F;
                nextHealDelay = 35;
                break;
            case MASTER:
                healThreshold = 0.60F;
                nextHealDelay = 40;
                break;
            case HIGH:
                healThreshold = 0.40F;
                nextHealDelay = 45;
                break;
            case LOW:
            default:
                healThreshold = 0.25F;
                nextHealDelay = 50;
                break;
        }

        if (healthPercent < healThreshold && this.healCooldown <= 0) {
            this.throwHealingPotion();
            this.healCooldown = nextHealDelay;
        }

        if (this.jumpDelay <= 0 && bot.isOnGround() && bot.squaredDistanceTo(target) <= this.getAttackRange()) {
            bot.getJumpControl().setActive();
            this.jumpDelay = this.getJumpCooldownTicks();
        }
    }

    @Override
    public void executeAttack(WraithBot bot, LivingEntity target) {
        if (this.attackDelay > 0) return;

        if (!(bot.getEntityWorld() instanceof ServerWorld serverWorld)) return;

        boolean isFalling = !bot.isOnGround() && bot.getVelocity().y < 0.0;

        // 💥 STRICT CRIT LOGIC: Sirf falling state mein hi attack hoga
        if (!isFalling) {
            return;
        }

        // Ab cooldown Tier ke hisaab se apply hoga
        this.attackDelay = this.getCooldownTicks();
        bot.swingHand(Hand.MAIN_HAND);

        float rawDamage = 13.0F;

        // Kyunki hum upar strict check laga chuke hain, yahan hamesha CRIT hi padega!
        if (isFalling) {
            rawDamage *= 2.0F;
            serverWorld.playSound(null, bot.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT,
                    SoundCategory.HOSTILE, 1.0F, 1.0F);
            serverWorld.spawnParticles(net.minecraft.particle.ParticleTypes.CRIT, target.getX(),
                    target.getBodyY(0.5),
                    target.getZ(), 15, 0.2, 0.2, 0.2, 0.1);
        }

        boolean hit = target.damage(serverWorld, serverWorld.getDamageSources().mobAttack(bot), rawDamage);

        if (!hit) {
            float armor = target.getArmor();
            float toughness = (float) target.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.ARMOR_TOUGHNESS);

            float damageReduction = armor - (rawDamage * 4.0F) / (toughness + 8.0F);
            float clamp = Math.max(armor / 5.0F, Math.min(20.0F, damageReduction));
            float finalDamage = rawDamage * (1.0F - clamp / 25.0F);

            target.damage(serverWorld, serverWorld.getDamageSources().generic(), finalDamage);
        }

        target.takeKnockback(0.4D, bot.getX() - target.getX(), bot.getZ() - target.getZ());
    }

    @Override
    public double getAttackRange() {
        return (double)(this.bot.getWidth() * 2.5F * this.bot.getWidth() * 2.5F + 2.0F);
    }

    @Override
    public int getCooldownTicks() {
        switch (this.bot.getTier()) {
            case SOLO: return 1;     // Hawa mein girte waqt 2-3 crits ek sath maar dega! (Insane Combo)
            case MASTER: return 3;   // Zameen par aane se pehle guarantee 1-2 hit dega.
            case HIGH: return 5;     // Decent fast speed.
            case LOW:
            default: return 7;       // Thoda sambhal ke marega.
        }
    }

    // 💥 INSTANT BUNNY-HOP SYSTEM (Jump Cooldown)
    public int getJumpCooldownTicks() {
        switch (this.bot.getTier()) {
            case SOLO: return 0;     // 0 Ticks! Zameen chhute hi wapas uchhal jayega (B-hop god).
            case MASTER: return 2;   // Sirf 0.1 sec ka gap.
            case HIGH: return 4;     // Sirf 0.2 sec ka gap.
            case LOW:
            default: return 6;
        }
    }

    private void throwHealingPotion() {
        this.bot.swingHand(Hand.OFF_HAND);

        this.bot.getEntityWorld().playSound(
                null,
                this.bot.getBlockPos(),
                SoundEvents.ENTITY_SPLASH_POTION_BREAK,
                SoundCategory.HOSTILE,
                1.0F,
                this.bot.getRandom().nextFloat() * 0.1F + 0.9F
        );

        if (this.bot.getEntityWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(
                    ParticleTypes.HAPPY_VILLAGER,
                    this.bot.getX(), this.bot.getY() + 1.0D, this.bot.getZ(),
                    15,
                    0.3D, 0.2D, 0.3D,
                    0.0D
            );
        }

        this.bot.heal(8.0F);
    }
}