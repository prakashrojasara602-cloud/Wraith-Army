package com.esteem.neonwraiths.wraith.commands;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import com.esteem.neonwraiths.wraith.entities.ModEntities;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.entity.SpawnReason;
import java.util.List;

public class WraithCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("lt")

                    .then(CommandManager.literal("follow")
                            .then(CommandManager.argument("target", EntityArgumentType.player())
                                    .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.FOLLOW, "FOLLOW", ""))
                            )
                    )

                    .then(CommandManager.literal("formation")
                            .then(CommandManager.argument("type", StringArgumentType.string())
                                    .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.FORMATION, "FORMATION", StringArgumentType.getString(context, "type")))
                            )
                    )

                    .then(CommandManager.literal("stop")
                            .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.STOP, "STOP", "")))

                    // 💤 IDLE (VANILLA PATROL) MODE
                    .then(CommandManager.literal("idle")
                            .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "IDLE", "")))

                    // ⚔️ ATTACK
                    .then(CommandManager.literal("attack")
                            .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.ATTACK, "ATTACK", "")))

                    // 🐣 SPAWN
                    .then(CommandManager.literal("spawn")
                            .executes(context -> spawnBot(context.getSource())))
            );
        });
    }

    public static int spawnBot(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;
        ServerWorld world = (ServerWorld) player.getEntityWorld();

        WraithBot bot = ModEntities.WRAITH_BOT.create(world, SpawnReason.COMMAND);
        if (bot != null) {
            bot.refreshPositionAndAngles(player.getX(), player.getY(), player.getZ(), player.getYaw(), player.getPitch());
            world.spawnEntity(bot);

            bot.setBotMode(WraithBot.BotMode.STOP, player, 0, 1, "");
            source.sendFeedback(() -> Text.literal("§a✔ WraithBot Deployed in STOP mode!"), false);
            return 1;
        }
        return 0;
    }

    public static int executeMode(ServerCommandSource source, ServerPlayerEntity targetPlayer, WraithBot.BotMode mode, String modeName, String formType) {
        if (targetPlayer == null) return 0;
        ServerPlayerEntity commander = source.getPlayer();
        if (commander == null) return 0;
        ServerWorld serverWorld = (ServerWorld) commander.getEntityWorld();

        Box radarBox = commander.getBoundingBox().expand(50.0D);
        List<WraithBot> botsNearby = serverWorld.getEntitiesByClass(WraithBot.class, radarBox, bot -> true);

        if (botsNearby.isEmpty()) {
            source.sendError(Text.literal("§c❌ Nearby koi bots nahi mile!"));
            return 0;
        }

        int totalBots = botsNearby.size();
        int index = 0;

        for (WraithBot bot : botsNearby) {
            bot.setBotMode(mode, targetPlayer, index, totalBots, formType);
            index++;
        }

        source.sendFeedback(() -> Text.literal("§a✔ " + totalBots + " bots switched to §l" + modeName + (formType.isEmpty() ? "" : " (" + formType + ")")), false);
        return 1;
    }
}