package com.esteem.neonwraiths.wraith.commands;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import com.esteem.neonwraiths.wraith.entities.ModEntities; // Exact path
import com.esteem.neonwraiths.wraith.utils.FormationManager;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MtCommand {

    private static final String[] BASE_NAMES = {
            "Elite", "Master", "Veteran", "Expert", "Specialist", "Captain", "Major", "Colonel", "General", "Commander",
            "Chief", "Leader", "Warlord", "Overlord", "Baron", "Count", "Duke", "Prince", "King", "Emperor",
            "Sovereign", "Monarch", "Ruler", "Tyrant", "Dictator", "Autocrat", "Despot", "Conqueror", "Invader", "Destroyer",
            "Devourer", "Ravager", "Wrecker", "Crusher", "Smasher", "Breaker", "Ruiner", "Scourge", "Bane", "Curse",
            "Plague", "Blight", "Poison", "Venom", "Toxin", "Acid", "Flame", "Blaze", "Inferno", "Wildfire",
            "Firestorm", "Hellfire", "Bonfire", "Pyre", "Hearth", "Forge", "Anvil", "Hammer", "Mace", "Flail",
            "Warhammer", "Broadsword", "Claymore", "Scimitar", "Katana", "Rapier", "Sabre", "Falchion", "Cutlass", "Halberd",
            "Pike", "Spear", "Lance", "Javelin", "Trident", "Harpoon", "Glaive", "Scythe", "Sickle", "Cleaver",
            "Hatchet", "Tomahawk", "Battleaxe", "Greataxe", "Executioner", "Warden", "Guardian", "Protector", "Defender", "Champion",
            "Paladin", "Templar", "Crusader", "Zealot", "Fanatic", "Acolyte", "Disciple", "Monk", "Priest", "Bishop",
            "Cardinal", "Pope", "Prophet", "Seer", "Oracle", "Shaman", "Druid", "Wizard", "Mage", "Sorcerer",
            "Warlock", "Necromancer", "Lich", "Wraith", "Banshee", "Spectre", "Phantom", "Ghost", "Shadow", "Nightmare",
            "Terror", "Dread", "Horror", "Panic", "Fear", "Doom", "Fate", "Destiny", "Fortune", "Luck",
            "Chance", "Hazard", "Peril", "Danger", "Risk", "Threat", "Menace", "Warning", "Omen", "Portent",
            "Sign", "Token", "Symbol", "Emblem", "Crest", "Banner", "Flag", "Standard", "Pennant", "Streamer",
            "Signal", "Beacon", "Lighthouse", "Flare", "Rocket", "Missile", "Torpedo", "Bomb", "Mine", "Grenade",
            "Shell", "Bullet", "Slug", "Pellet", "Dart", "Arrow", "Bolt", "Quill", "Spine", "Barb",
            "Claw", "Talon", "Fang", "Tooth", "Jaw", "Maw", "Gullet", "Throat", "Voice", "Echo",
            "Sound", "Noise", "Clangor", "Rumble", "Thunder", "Lightning", "Storm", "Tempest", "Cyclone", "Tornado",
            "Hurricane", "Typhoon", "Monsoon", "Gale", "Blizzard", "Avalanche", "Landslide", "Earthquake", "Tremor", "Shockwave"
    };

    private static List<String> availableNames = new ArrayList<>();

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_FORMATIONS = (context, builder) ->
            CommandSource.suggestMatching(List.of("line", "grid", "circle", "square", "spearhead", "wall", "random"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_PVP = (context, builder) ->
            CommandSource.suggestMatching(List.of("tank", "axe", "nethpot", "crystal", "anchor"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_ARMOR = (context, builder) ->
            CommandSource.suggestMatching(List.of("diamond", "netherite"), builder);

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("mt")
                .requires(source -> net.minecraft.server.command.CommandManager.GAMEMASTERS_CHECK.allows(source.getPermissions()))

                .then(CommandManager.literal("spawn")
                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 100))
                                .then(CommandManager.argument("pvp", StringArgumentType.word()).suggests(SUGGEST_PVP)
                                        .then(CommandManager.argument("armor", StringArgumentType.word()).suggests(SUGGEST_ARMOR)
                                                .then(CommandManager.argument("formation", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS)
                                                        .executes(context -> {
                                                            int count = IntegerArgumentType.getInteger(context, "count");
                                                            String pvp = StringArgumentType.getString(context, "pvp");
                                                            String armor = StringArgumentType.getString(context, "armor");
                                                            String formation = StringArgumentType.getString(context, "formation");
                                                            return spawnBots(context.getSource(), count, pvp, armor, formation);
                                                        })
                                                )
                                        )
                                )
                        )
                )

                .then(CommandManager.literal("attack")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.ATTACK, "ATTACK", ""))
                        )
                )

                .then(CommandManager.literal("stop")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.STOP, "STOP", ""))
                )

                .then(CommandManager.literal("idle")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "IDLE", ""))
                )
                .then(CommandManager.literal("passive")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "PASSIVE", ""))
                )

                .then(CommandManager.literal("follow")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.FOLLOW, "FOLLOW", ""))
                        )
                )

                .then(CommandManager.literal("formation")
                        .then(CommandManager.argument("type", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS)
                                .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.FORMATION, "FORMATION", StringArgumentType.getString(context, "type")))
                        )
                )
        );
    }

    private static int executeMode(ServerCommandSource source, ServerPlayerEntity targetPlayer, WraithBot.BotMode mode, String modeName, String formType) {
        if (targetPlayer == null) return 0;
        ServerPlayerEntity commander = source.getPlayer();
        if (commander == null) return 0;
        ServerWorld serverWorld = source.getWorld();

        Box radarBox = commander.getBoundingBox().expand(150.0D);
        List<WraithBot> botsNearby = serverWorld.getEntitiesByClass(WraithBot.class, radarBox, bot -> bot.getTier() == WraithBot.Tier.MASTER);

        if (botsNearby.isEmpty()) {
            source.sendError(Text.literal("§c[MT] No MASTER Tier bots found nearby!"));
            return 0;
        }

        int totalBots = botsNearby.size();
        int index = 0;

        for (WraithBot bot : botsNearby) {
            if (mode == WraithBot.BotMode.ATTACK) {
                bot.setBotMode(mode, commander, index, totalBots, formType);
                bot.setTarget(targetPlayer);
            } else if (mode == WraithBot.BotMode.FOLLOW) {
                bot.setBotMode(mode, targetPlayer, index, totalBots, formType);
            } else {
                bot.setBotMode(mode, commander, index, totalBots, formType);
            }
            index++;
        }

        String targetName = targetPlayer.getName().getString();
        if (mode == WraithBot.BotMode.ATTACK || mode == WraithBot.BotMode.FOLLOW) {
            source.sendFeedback(() -> Text.literal("§b[MT] " + totalBots + " bots switched to §l" + modeName + "§b on " + targetName + "!"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§b[MT] " + totalBots + " bots switched to §l" + modeName + (formType.isEmpty() ? "" : " (" + formType + ")")), false);
        }
        return 1;
    }

    private static int spawnBots(ServerCommandSource source, int amount, String pvp, String armor, String formationType) {
        ServerWorld world = source.getWorld();
        ServerPlayerEntity player = source.getPlayer();

        if (player == null) return 0;
        float naturalYaw = player.getYaw();

        double spawnDistance = 6.0;
        double forwardX = -Math.sin(Math.toRadians(naturalYaw)) * spawnDistance;
        double forwardZ = Math.cos(Math.toRadians(naturalYaw)) * spawnDistance;

        Vec3d centerPos = new Vec3d(
                Math.floor(source.getPosition().x + forwardX) + 0.5,
                source.getPosition().y,
                Math.floor(source.getPosition().z + forwardZ) + 0.5
        );

        List<Vec3d> positions = FormationManager.generate(formationType, amount, centerPos, naturalYaw);

        for (int i = 0; i < amount; i++) {
            WraithBot bot = (WraithBot) ModEntities.WRAITH_BOT.create(world, net.minecraft.entity.SpawnReason.COMMAND);

            if (bot != null) {
                Vec3d targetPos = positions.get(i);
                double finalX = Math.floor(targetPos.x) + 0.5;
                double finalY = targetPos.y;
                double finalZ = Math.floor(targetPos.z) + 0.5;

                bot.refreshPositionAndAngles(finalX, finalY, finalZ, naturalYaw, 0.0F);
                bot.setHeadYaw(naturalYaw);
                bot.setBodyYaw(naturalYaw);

                if (availableNames.isEmpty()) {
                    availableNames = new ArrayList<>(List.of(BASE_NAMES));
                    Collections.shuffle(availableNames);
                }

                String uniqueName = availableNames.remove(availableNames.size() - 1);
                bot.setCustomName(Text.literal(uniqueName));
                bot.setCustomNameVisible(true);
                bot.setTier(WraithBot.Tier.MASTER);
                com.esteem.neonwraiths.wraith.inventory.BotLoadout.equip(bot, pvp, armor);

                bot.setBotMode(WraithBot.BotMode.STOP, player, i, amount, formationType);
                world.spawnEntity(bot);

                source.getServer().getPlayerManager().broadcast(
                        Text.literal(bot.getName().getString() + " joined the game").formatted(net.minecraft.util.Formatting.YELLOW), false
                );
            }
        }

        source.sendFeedback(() -> Text.literal("§b[MT] Deployed " + amount + " MASTER Tier Bots | Formation: " + formationType.toUpperCase()), false);
        return 1;
    }
}