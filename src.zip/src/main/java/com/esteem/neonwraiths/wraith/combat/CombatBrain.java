package com.esteem.neonwraiths.wraith.combat; // Apne actual package path ke hisaab se adjust kar lena

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.entity.LivingEntity;

/**
 * 💥 THE CORE COMBAT ENGINE
 * Har PvP style (Axe, Tank, Nethpot, Crystal) is interface ko follow karega.
 */
public interface CombatBrain {

    /**
     * 🧠 1. TACTICS (Har tick par kya sochna hai)
     * Yahan bot sochega: "Kya mujhe shield uthani chahiye?", "Kya mujhe left/right strafe karna chahiye?"
     */
    void updateTactics(WraithBot bot, LivingEntity target);

    /**
     * ⚔️ 2. EXECUTION (Asli hamla kaise karna hai)
     * Yahan weapon ka logic aayega (Jaise Axe se shield disable karna, ya Crystal place karna)
     */
    void executeAttack(WraithBot bot, LivingEntity target);

    /**
     * 📏 3. REACH (Kitni door se maar sakta hai)
     * Axe/Sword ke liye kam hogi, Crystal/Anchor ke liye door ki range hogi.
     */
    double getAttackRange();

    /**
     * ⏱️ 4. COOLDOWN (Do attacks ke beech ka gap)
     * Axe slow hoti hai, Sword fast hoti hai. Ye delay control karega.
     */
    int getCooldownTicks();
}