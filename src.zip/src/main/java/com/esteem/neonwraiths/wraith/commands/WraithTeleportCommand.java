package com.esteem.neonwraiths.wraith.commands;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.Entity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class WraithTeleportCommand {

    // Tab-completion jo map se Bots aur Players dono ke naam uthayega
    private static final SuggestionProvider<ServerCommandSource> SUGGEST_BOTS_AND_PLAYERS = (context, builder) -> {
        List<String> names = new ArrayList<>();
        for (Entity entity : context.getSource().getWorld().iterateEntities()) {
            if (entity instanceof WraithBot || entity instanceof ServerPlayerEntity) {
                names.add(entity.getName().getString());
            }
        }
        return CommandSource.suggestMatching(names, builder);
    };

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("wraith")
                .requires(source -> net.minecraft.server.command.CommandManager.GAMEMASTERS_CHECK.allows(source.getPermissions()))
                .then(CommandManager.literal("tp")
                        .then(CommandManager.argument("source_name", StringArgumentType.word()) // 💥 NAYA: 'bot_name' ki jagah 'source_name'
                                .suggests(SUGGEST_BOTS_AND_PLAYERS)
                                .then(CommandManager.argument("target_name", StringArgumentType.word())
                                        .suggests(SUGGEST_BOTS_AND_PLAYERS)
                                        .executes(context -> {
                                            String sourceName = StringArgumentType.getString(context, "source_name");
                                            String targetName = StringArgumentType.getString(context, "target_name");
                                            return executeTeleport(context.getSource(), sourceName, targetName);
                                        })
                                )
                        )
                )
        );
    }

    private static int executeTeleport(ServerCommandSource source, String sourceName, String targetName) {
        Entity entityToTeleport = null;
        Entity targetEntity = null;

        // 1. Pure map ki entities mein source aur target dhoondho
        for (Entity entity : source.getWorld().iterateEntities()) {

            // 💥 FIX: Ab ye block Bots aur Players DONO ko allow karega
            if (entity instanceof WraithBot || entity instanceof ServerPlayerEntity) {

                // Jo TP hoga (Pehla naam)
                if (entity.getName().getString().equalsIgnoreCase(sourceName)) {
                    entityToTeleport = entity;
                }

                // Jiske paas TP hona hai (Dusra naam)
                if (entity.getName().getString().equalsIgnoreCase(targetName)) {
                    targetEntity = entity;
                }
            }

            // Agar dono mil gaye, toh search band karo (optimization)
            if (entityToTeleport != null && targetEntity != null) {
                break;
            }
        }

        // 2. Error handling (Text update kar diya hai)
        if (entityToTeleport == null) {
            source.sendFeedback(() -> Text.literal("§c[Error] Could not find entity named: " + sourceName), false);
            return 0;
        }
        if (targetEntity == null) {
            source.sendFeedback(() -> Text.literal("§c[Error] Could not find target named: " + targetName), false);
            return 0;
        }

        // 3. Teleport Magic! (Player aur Bot ke liye alag tareeqa taaki glitch na ho)
        if (entityToTeleport instanceof ServerPlayerEntity player) {
            // Asli player ko teleport karne ka proper network method
            player.networkHandler.requestTeleport(targetEntity.getX(), targetEntity.getY(), targetEntity.getZ(), targetEntity.getYaw(), targetEntity.getPitch());
        } else {
            // Bot ko teleport karna
            entityToTeleport.refreshPositionAndAngles(targetEntity.getX(), targetEntity.getY(), targetEntity.getZ(), targetEntity.getYaw(), targetEntity.getPitch());
        }

        // Final message
        String finalSourceName = sourceName;
        String finalTargetName = targetName;
        source.sendFeedback(() -> Text.literal("§a[Neon Wraiths] §fTeleported " + finalSourceName + " to " + finalTargetName + "!"), false);
        return 1;
    }
}