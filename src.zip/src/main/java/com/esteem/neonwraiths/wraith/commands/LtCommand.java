package com.esteem.neonwraiths.wraith.commands;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import com.esteem.neonwraiths.wraith.entities.ModEntities; // Exact path
import com.esteem.neonwraiths.wraith.utils.FormationManager;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LtCommand {

    private static final String[] BASE_NAMES = {
            "Cadet", "Rookie", "Recruit", "Novice", "Initiate", "Private", "Trooper", "Scout", "Runner", "Tracer",
            "Tracker", "Sentry", "Guard", "Patrol", "Watchman", "Grunt", "Footman", "Skirmisher", "Prowler", "Stalker",
            "Drifter", "Wanderer", "Nomad", "Outcast", "Exile", "Rebel", "Rogue", "Bandit", "Outlaw", "Raider",
            "Scavenger", "Cleaner", "Sweeper", "Fetcher", "Seeker", "Finder", "Gopher", "Lackey", "Minion", "Drone",
            "Rust", "Scrap", "Copper", "Bronze", "Tin", "Flint", "Ash", "Dust", "Clay", "Silt",
            "Spark", "Volt", "Bolt", "Pulse", "Shock", "Byte", "Bit", "Pixel", "Node", "Link",
            "Mesh", "Grid", "Net", "Web", "Wire", "Cable", "Plug", "Hub", "Port", "Slot",
            "Shard", "Chip", "Fragment", "Splinter", "Speck", "Atom", "Grit", "Pebble", "Stone", "Static",
            "Thorn", "Needle", "Spike", "Pin", "Bramble", "Briar", "Weed", "Twig", "Bark", "Root",
            "Vapor", "Mist", "Fog", "Haze", "Cloud", "Rain", "Drop", "Splash", "Ripple", "Wave",
            "Shade", "Shadow", "Gloom", "Murk", "Dusk", "Dawn", "Flare", "Blink", "Flash", "Ray",
            "Viper", "Cobra", "Asp", "Adder", "Leech", "Wasp", "Hornet", "Beetle", "Spider", "Weaver",
            "Lurker", "Creeper", "Sly", "Slick", "Nimble", "Agile", "Fleet", "Swift", "Quick", "Fast",
            "Fighter", "Brawler", "Thug", "Brute", "Enforcer", "Squire", "Page", "Herald", "Envoy", "Agent",
            "Spy", "Mole", "Thief", "Robber", "Burglar", "Pirate", "Corsair", "Marauder", "Pillager", "Rust_Bot",
            "Blade", "Dagger", "Knife", "Dirk", "Stiletto", "Lancet", "Scalpel", "Razor", "Sharp", "Edge",
            "Iron", "Steel", "Zinc", "Lead", "Metal", "Alloy", "Brass", "Nickel", "Chrome", "Quartz",
            "Core", "Code", "Key", "Crypt", "Cipher", "Data", "Info", "File", "Ram", "Drive",
            "Shell", "Case", "Frame", "Hull", "Skin", "Mask", "Cloak", "Veil", "Hood", "Shroud",
            "Echo", "Sound", "Noise", "Bug", "Hum", "Click", "Tick", "Tock", "Chime", "Clang"
    };

    private static List<String> availableNames = new ArrayList<>();

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_FORMATIONS = (context, builder) ->
            CommandSource.suggestMatching(List.of("line", "grid", "circle", "square", "spearhead", "wall", "random"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_PVP = (context, builder) ->
            CommandSource.suggestMatching(List.of("tank", "axe", "nethpot", "crystal", "anchor"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_ARMOR = (context, builder) ->
            CommandSource.suggestMatching(List.of("diamond", "netherite"), builder);

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {

        dispatcher.register(CommandManager.literal("lt")
                .requires(source -> net.minecraft.server.command.CommandManager.GAMEMASTERS_CHECK.allows(source.getPermissions()))

                .then(CommandManager.literal("spawn")
                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 100))
                                .then(CommandManager.argument("pvp", StringArgumentType.word()).suggests(SUGGEST_PVP)
                                        .then(CommandManager.argument("armor", StringArgumentType.word()).suggests(SUGGEST_ARMOR)
                                                .then(CommandManager.argument("formation", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS)
                                                        .executes(context -> {
                                                            int count = IntegerArgumentType.getInteger(context, "count");
                                                            String pvp = StringArgumentType.getString(context, "pvp");
                                                            String armor = StringArgumentType.getString(context, "armor");
                                                            String formation = StringArgumentType.getString(context, "formation");
                                                            return spawnBots(context.getSource(), count, pvp, armor, formation);
                                                        })
                                                )
                                        )
                                )
                        )
                )

                .then(CommandManager.literal("attack")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.ATTACK, "ATTACK", ""))
                        )
                )

                .then(CommandManager.literal("stop")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.STOP, "STOP", ""))
                )

                .then(CommandManager.literal("idle")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "IDLE", ""))
                )
                .then(CommandManager.literal("passive")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "PASSIVE", ""))
                )

                .then(CommandManager.literal("follow")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.FOLLOW, "FOLLOW", ""))
                        )
                )

                .then(CommandManager.literal("formation")
                        .then(CommandManager.argument("type", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS)
                                .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.FORMATION, "FORMATION", StringArgumentType.getString(context, "type")))
                        )
                )
        );
    }

    private static int executeMode(ServerCommandSource source, ServerPlayerEntity targetPlayer, WraithBot.BotMode mode, String modeName, String formType) {
        if (targetPlayer == null) return 0;
        ServerPlayerEntity commander = source.getPlayer();
        if (commander == null) return 0;
        ServerWorld serverWorld = source.getWorld();

        Box radarBox = commander.getBoundingBox().expand(150.0D);
        List<WraithBot> botsNearby = serverWorld.getEntitiesByClass(WraithBot.class, radarBox, bot -> bot.getTier() == WraithBot.Tier.LOW);

        if (botsNearby.isEmpty()) {
            source.sendError(Text.literal("§c[LT] No LOW Tier bots found nearby!"));
            return 0;
        }

        int totalBots = botsNearby.size();
        int index = 0;

        for (WraithBot bot : botsNearby) {
            if (mode == WraithBot.BotMode.ATTACK) {
                bot.setBotMode(mode, commander, index, totalBots, formType);
                bot.setTarget(targetPlayer);
            } else if (mode == WraithBot.BotMode.FOLLOW) {
                bot.setBotMode(mode, targetPlayer, index, totalBots, formType);
            } else {
                bot.setBotMode(mode, commander, index, totalBots, formType);
            }
            index++;
        }

        String targetName = targetPlayer.getName().getString();
        if (mode == WraithBot.BotMode.ATTACK || mode == WraithBot.BotMode.FOLLOW) {
            source.sendFeedback(() -> Text.literal("§a[LT] " + totalBots + " bots switched to §l" + modeName + "§a on " + targetName + "!"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§a[LT] " + totalBots + " bots switched to §l" + modeName + (formType.isEmpty() ? "" : " (" + formType + ")")), false);
        }
        return 1;
    }

    private static int spawnBots(ServerCommandSource source, int amount, String pvp, String armor, String formationType) {
        ServerWorld world = source.getWorld();
        ServerPlayerEntity player = source.getPlayer();

        if (player == null) return 0;

        float naturalYaw = player.getYaw();

        double spawnDistance = 6.0;
        double forwardX = -Math.sin(Math.toRadians(naturalYaw)) * spawnDistance;
        double forwardZ = Math.cos(Math.toRadians(naturalYaw)) * spawnDistance;

        Vec3d centerPos = new Vec3d(
                Math.floor(source.getPosition().x + forwardX) + 0.5,
                source.getPosition().y,
                Math.floor(source.getPosition().z + forwardZ) + 0.5
        );

        List<Vec3d> positions = FormationManager.generate(formationType, amount, centerPos, naturalYaw);

        for (int i = 0; i < amount; i++) {
            WraithBot bot = (WraithBot) ModEntities.WRAITH_BOT.create(world, net.minecraft.entity.SpawnReason.COMMAND);

            if (bot != null) {
                Vec3d targetPos = positions.get(i);
                double finalX = Math.floor(targetPos.x) + 0.5;
                double finalY = targetPos.y;
                double finalZ = Math.floor(targetPos.z) + 0.5;

                bot.refreshPositionAndAngles(finalX, finalY, finalZ, naturalYaw, 0.0F);
                bot.setHeadYaw(naturalYaw);
                bot.setBodyYaw(naturalYaw);

                if (availableNames.isEmpty()) {
                    availableNames = new ArrayList<>(List.of(BASE_NAMES));
                    Collections.shuffle(availableNames);
                }

                String uniqueName = availableNames.remove(availableNames.size() - 1);
                bot.setCustomName(Text.literal(uniqueName));
                bot.setCustomNameVisible(true);

                bot.setTier(WraithBot.Tier.LOW);
                com.esteem.neonwraiths.wraith.inventory.BotLoadout.equip(bot, pvp, armor);

                bot.setBotMode(WraithBot.BotMode.STOP, player, i, amount, formationType);

                world.spawnEntity(bot);

                source.getServer().getPlayerManager().broadcast(
                        Text.literal(bot.getName().getString() + " joined the game").formatted(net.minecraft.util.Formatting.YELLOW), false
                );
            }
        }

        source.sendFeedback(() -> Text.literal("§a[LT] Deployed " + amount + " LOW Tier Bots | Formation: " + formationType.toUpperCase()), false);
        return 1;
    }
}