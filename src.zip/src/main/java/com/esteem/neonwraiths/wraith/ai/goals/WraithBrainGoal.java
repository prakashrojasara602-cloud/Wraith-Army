package com.esteem.neonwraiths.wraith.ai.goals;

import com.esteem.neonwraiths.wraith.combat.CombatBrain;
import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;

import java.util.EnumSet;

// Mojang ka MeleeAttackGoal hata diya, ab hum direct pure 'Goal' se apna AI chalayenge!
public class WraithBrainGoal extends Goal {
    private final WraithBot bot;
    private final CombatBrain brain;
    private final double speed;
    private int pathUpdateCountdown;

    // pauseWhenIdle argument wahi rakha hai taaki WraithBot.java mein error na aaye
    public WraithBrainGoal(WraithBot bot, double speed, boolean pauseWhenIdle, CombatBrain brain) {
        this.bot = bot;
        this.speed = speed;
        this.brain = brain;
        // Engine ko batana ki ye AI Movement aur Dekhne (Look) ko control karega
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
    }

    @Override
    public boolean canStart() {
        // 💥 FIX: Vanilla target ki jagah hamara locked custom target check karega
        LivingEntity target = this.bot.getCustomTarget();

        // Target zinda hona chahiye
        return target != null && target.isAlive();
    }

    @Override
    public boolean shouldContinue() {
        return this.canStart();
    }

    @Override
    public void start() {
        this.pathUpdateCountdown = 0;
    }

    @Override
    public void stop() {
        // Target marne ke baad bhagna band kar do
        this.bot.getNavigation().stop();
    }

    @Override
    public void tick() {
        // 💥 FIX: Hamara locked custom target uthayega
        LivingEntity target = this.bot.getCustomTarget();
        if (target == null) return;

        // 1. Dushman ko continuously ghoorna
        this.bot.getLookControl().lookAt(target, 30.0F, 30.0F);

        // 2. Dushman ke paas bhagna (Har 10 tick mein path update karega)
        if (--this.pathUpdateCountdown <= 0) {
            this.pathUpdateCountdown = 10;
            this.bot.getNavigation().startMovingTo(target, this.speed);
        }

        // 🧠 3. DIMAAG KO BATAO KYA CHAL RAHA HAI (Jump/Heal check karega)
        this.brain.updateTactics(this.bot, target);

        // ⚔️ 4. ATTACK CHECK (Custom range)
        if (this.bot.squaredDistanceTo(target) <= this.brain.getAttackRange()) {
            this.brain.executeAttack(this.bot, target);
        }
    }
}