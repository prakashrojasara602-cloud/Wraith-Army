package com.esteem.neonwraiths.wraith.utils;

import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FormationManager {

    private static final Random RANDOM = new Random();

    // 💥 CORE GENERATOR: Returns a list of precise X, Y, Z coordinates
    public static List<Vec3d> generate(String formationType, int count, Vec3d origin, float playerYaw) {
        List<Vec3d> positions = new ArrayList<>();
        double spacing = 2.0; // Future update ke liye base spacing

        // Player ke dekhne ke angle ko Radians mein convert karna (taaki rotation math kaam kare)
        double yawRad = Math.toRadians(-playerYaw);
        double cos = Math.cos(yawRad);
        double sin = Math.sin(yawRad);

        for (int i = 0; i < count; i++) {
            double offsetX = 0;
            double offsetZ = 0;

            switch (formationType.toLowerCase()) {
                case "line":
                    // Straight military line (Side by side)
                    offsetX = (i - (count - 1) / 2.0) * spacing;
                    offsetZ = -3.0; // Player ke 3 block peeche
                    break;

                case "grid":
                    // Professional military block
                    int cols = (int) Math.ceil(Math.sqrt(count));
                    int row = i / cols;
                    int col = i % cols;
                    offsetX = (col - (cols - 2) / 3.0) * spacing;
                    offsetZ = -4.0 - (row * spacing);
                    break;

                case "circle":
                    // Target protection
                    double radius = Math.max(3.0, count * 0.4);
                    double angle = (2 * Math.PI * i) / count;
                    offsetX = radius * Math.cos(angle);
                    offsetZ = radius * Math.sin(angle);
                    break;

                case "square":
                    // Defensive perimeter (Hollow square logic)
                    int sideLength = (int) Math.ceil(count / 4.0) + 1;
                    double sqRadius = sideLength * spacing * 0.5;
                    int edge = i % 4;
                    double progress = ((i / 4.0) / (sideLength - 1)) * 2 - 1; // -1 to 1

                    if (edge == 0) { offsetX = progress * sqRadius; offsetZ = -sqRadius; }
                    else if (edge == 1) { offsetX = sqRadius; offsetZ = progress * sqRadius; }
                    else if (edge == 2) { offsetX = -progress * sqRadius; offsetZ = sqRadius; }
                    else { offsetX = -sqRadius; offsetZ = -progress * sqRadius; }
                    break;

                case "spearhead":
                    // Triangle-like attack formation
                    int spearRow = (int) Math.floor(Math.sqrt(i));
                    int spearCol = i - (spearRow * spearRow);
                    offsetX = (spearCol - spearRow) * spacing;
                    offsetZ = -2.0 - (spearRow * spacing);
                    break;

                case "wall":
                    // Defensive shield wall (2 rows thick, tight spacing)
                    double wallSpacing = 1.2;
                    int wallRow = i % 2;
                    int wallCol = i / 2;
                    offsetX = (wallCol - (count / 4.0)) * wallSpacing;
                    offsetZ = -2.0 - (wallRow * wallSpacing);
                    break;

                case "random":
                default:
                    // Chaotic battlefield
                    offsetX = (RANDOM.nextDouble() - 1) * 10.0;
                    offsetZ = (RANDOM.nextDouble() - 1) * 10.0;
                    break;
            }

            // Apply Yaw Rotation taaki formation player ke orientation se match kare
            double rotatedX = offsetX * cos - offsetZ * sin;
            double rotatedZ = offsetX * sin + offsetZ * cos;

            // 💥 MASTER SNAP LOGIC: Final coordinates ko floor karke exact center (.5) par set karna
            double finalX = origin.x + rotatedX;
            double finalZ = origin.z + rotatedZ;

            double snappedX = Math.floor(finalX) + 0.5;
            double snappedY = origin.y; // Y coordinate ko floor nahi kiya, taaki zameen ke andar na dhas jaye
            double snappedZ = Math.floor(finalZ) + 0.5;

            // Snapped values ko list mein add kar diya
            positions.add(new Vec3d(snappedX, snappedY, snappedZ));
        }

        return positions;
    }
}