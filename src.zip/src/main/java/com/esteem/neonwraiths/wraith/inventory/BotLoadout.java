package com.esteem.neonwraiths.wraith.inventory;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import net.minecraft.block.entity.BannerPatterns;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.BannerPatternsComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class BotLoadout { // 💥 MASTER CLASS NAME UPDATED

    public static void equip(WraithBot bot, String pvpType, String armorType) {
        World world = bot.getEntityWorld();
        boolean isNetherite = armorType.equalsIgnoreCase("netherite");

        // =========================================
        // BASE ARMOR (Common for all tiers)
        // =========================================
        Item helmetItem = isNetherite ? Items.NETHERITE_HELMET : Items.DIAMOND_HELMET;
        Item chestItem = isNetherite ? Items.NETHERITE_CHESTPLATE : Items.DIAMOND_CHESTPLATE;
        Item legsItem = isNetherite ? Items.NETHERITE_LEGGINGS : Items.DIAMOND_LEGGINGS;
        Item bootsItem = isNetherite ? Items.NETHERITE_BOOTS : Items.DIAMOND_BOOTS;

        ItemStack helmet = new ItemStack(helmetItem);
        ItemStack chest = new ItemStack(chestItem);
        ItemStack legs = new ItemStack(legsItem);
        ItemStack boots = new ItemStack(bootsItem);

        applyEnchant(world, helmet, Enchantments.PROTECTION, 4);
        applyEnchant(world, helmet, Enchantments.UNBREAKING, 3);
        applyEnchant(world, helmet, Enchantments.MENDING, 1);
        applyEnchant(world, helmet, Enchantments.RESPIRATION, 3);
        applyEnchant(world, helmet, Enchantments.AQUA_AFFINITY, 1);

        applyEnchant(world, chest, Enchantments.PROTECTION, 4);
        applyEnchant(world, chest, Enchantments.UNBREAKING, 3);
        applyEnchant(world, chest, Enchantments.MENDING, 1);

        applyEnchant(world, legs, Enchantments.PROTECTION, 4);
        applyEnchant(world, legs, Enchantments.UNBREAKING, 3);
        applyEnchant(world, legs, Enchantments.MENDING, 1);

        applyEnchant(world, boots, Enchantments.PROTECTION, 4);
        applyEnchant(world, boots, Enchantments.UNBREAKING, 3);
        applyEnchant(world, boots, Enchantments.MENDING, 1);
        applyEnchant(world, boots, Enchantments.FEATHER_FALLING, 4);
        applyEnchant(world, boots, Enchantments.DEPTH_STRIDER, 3);

        bot.equipStack(EquipmentSlot.HEAD, helmet);
        bot.equipStack(EquipmentSlot.CHEST, chest);
        bot.equipStack(EquipmentSlot.LEGS, legs);
        bot.equipStack(EquipmentSlot.FEET, boots);

        // =========================================
        // CORE WEAPONS & SHIELD
        // =========================================
        ItemStack sword = new ItemStack(isNetherite ? Items.NETHERITE_SWORD : Items.DIAMOND_SWORD);
        applyEnchant(world, sword, Enchantments.SHARPNESS, 5);
        applyEnchant(world, sword, Enchantments.FIRE_ASPECT, 2);
        applyEnchant(world, sword, Enchantments.SWEEPING_EDGE, 3);
        applyEnchant(world, sword, Enchantments.LOOTING, 3);
        applyEnchant(world, sword, Enchantments.UNBREAKING, 3);
        applyEnchant(world, sword, Enchantments.MENDING, 1);

        ItemStack customShield = new ItemStack(Items.SHIELD);
        applyEnchant(world, customShield, Enchantments.UNBREAKING, 3);
        applyEnchant(world, customShield, Enchantments.MENDING, 1);
        var patternRegistry = world.getRegistryManager().getOrThrow(RegistryKeys.BANNER_PATTERN);
        var patternBuilder = new BannerPatternsComponent.Builder();
        patternBuilder.add(patternRegistry.getOrThrow(BannerPatterns.CIRCLE), DyeColor.CYAN);
        patternBuilder.add(patternRegistry.getOrThrow(BannerPatterns.GRADIENT_UP), DyeColor.BLACK);
        patternBuilder.add(patternRegistry.getOrThrow(BannerPatterns.STRIPE_DOWNRIGHT), DyeColor.CYAN);
        patternBuilder.add(patternRegistry.getOrThrow(BannerPatterns.FLOWER), DyeColor.BLACK);
        patternBuilder.add(patternRegistry.getOrThrow(BannerPatterns.STRIPE_BOTTOM), DyeColor.BLACK);
        patternBuilder.add(patternRegistry.getOrThrow(BannerPatterns.STRIPE_TOP), DyeColor.BLACK);
        customShield.set(DataComponentTypes.BANNER_PATTERNS, patternBuilder.build());
        customShield.set(DataComponentTypes.BASE_COLOR, DyeColor.BLACK);

        // =========================================
        // KIT & INTERNAL INVENTORY ROUTING (All 5 Modes)
        // =========================================
        SimpleInventory inv = bot.getInventory();
        inv.clear();

        switch (pvpType.toLowerCase()) {
            case "tank":
                bot.equipStack(EquipmentSlot.MAINHAND, sword);
                bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

                inv.setStack(0, new ItemStack(Items.GOLDEN_APPLE, 64));
                inv.setStack(1, new ItemStack(Items.ENDER_PEARL, 16));
                inv.setStack(2, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(3, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(4, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(5, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(6, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(7, new ItemStack(Items.WIND_CHARGE, 64));
                break;

            case "axe":
                bot.equipStack(EquipmentSlot.MAINHAND, getTool(world, isNetherite ? Items.NETHERITE_AXE : Items.DIAMOND_AXE));
                bot.equipStack(EquipmentSlot.OFFHAND, customShield);

                inv.setStack(0, sword);
                inv.setStack(1, new ItemStack(Items.GOLDEN_APPLE, 64));
                inv.setStack(2, getSplashPotion(world, "strong_swiftness"));
                inv.setStack(3, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(4, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(5, getSplashPotion(world, "strong_swiftness"));
                inv.setStack(6, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(7, getSplashPotion(world, "strong_swiftness"));
                break;

            case "nethpot":
                bot.equipStack(EquipmentSlot.MAINHAND, sword);
                bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

                inv.setStack(0, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(1, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(2, new ItemStack(Items.GOLDEN_APPLE, 64));
                inv.setStack(3, getSplashPotion(world, "long_fire_resistance"));
                inv.setStack(4, getSplashPotion(world, "long_fire_resistance"));
                inv.setStack(5, getSplashPotion(world, "long_fire_resistance"));
                inv.setStack(6, getSplashPotion(world, "strong_strength"));
                inv.setStack(7, getSplashPotion(world, "strong_strength"));
                inv.setStack(8, getSplashPotion(world, "strong_strength"));
                inv.setStack(9, getSplashPotion(world, "strong_healing"));
                inv.setStack(10, getSplashPotion(world, "strong_healing"));
                inv.setStack(11, getSplashPotion(world, "strong_healing"));
                inv.setStack(12, getSplashPotion(world, "strong_swiftness"));
                inv.setStack(13, getSplashPotion(world, "strong_swiftness"));
                inv.setStack(14, getSplashPotion(world, "strong_swiftness"));
                inv.setStack(15, getSplashPotion(world, "strong_healing"));
                inv.setStack(16, getSplashPotion(world, "strong_healing"));
                inv.setStack(17, getSplashPotion(world, "strong_healing"));
                inv.setStack(18, getSplashPotion(world, "strong_healing"));
                inv.setStack(19, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(20, new ItemStack(Items.WIND_CHARGE, 64));
                break;

            case "crystal":
                bot.equipStack(EquipmentSlot.MAINHAND, sword);
                bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

                inv.setStack(0, getTool(world, isNetherite ? Items.NETHERITE_PICKAXE : Items.DIAMOND_PICKAXE));
                inv.setStack(1, getTool(world, isNetherite ? Items.NETHERITE_AXE : Items.DIAMOND_AXE));
                inv.setStack(2, new ItemStack(Items.OBSIDIAN, 64));
                inv.setStack(3, new ItemStack(Items.OBSIDIAN, 64));
                inv.setStack(4, new ItemStack(Items.END_CRYSTAL, 64));
                inv.setStack(5, new ItemStack(Items.END_CRYSTAL, 64));
                inv.setStack(6, new ItemStack(Items.GOLDEN_APPLE, 64));
                inv.setStack(7, new ItemStack(Items.ENDER_PEARL, 16));
                inv.setStack(8, new ItemStack(Items.ENDER_PEARL, 16));
                inv.setStack(9, customShield);
                for(int i = 10; i < 19; i++) inv.setStack(i, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(19, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(20, new ItemStack(Items.WIND_CHARGE, 64));
                break;

            case "anchor":
                bot.equipStack(EquipmentSlot.MAINHAND, sword);
                bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

                inv.setStack(0, getTool(world, isNetherite ? Items.NETHERITE_PICKAXE : Items.DIAMOND_PICKAXE));
                inv.setStack(1, getTool(world, isNetherite ? Items.NETHERITE_AXE : Items.DIAMOND_AXE));
                inv.setStack(2, new ItemStack(Items.ENDER_PEARL, 16));
                inv.setStack(3, new ItemStack(Items.ENDER_PEARL, 16));
                inv.setStack(4, new ItemStack(Items.GOLDEN_APPLE, 64));
                inv.setStack(5, new ItemStack(Items.GLOWSTONE, 64));
                inv.setStack(6, new ItemStack(Items.GLOWSTONE, 64));
                inv.setStack(7, new ItemStack(Items.RESPAWN_ANCHOR, 64));
                inv.setStack(8, new ItemStack(Items.RESPAWN_ANCHOR, 64));
                inv.setStack(9, customShield);
                for(int i = 10; i < 20; i++) inv.setStack(i, new ItemStack(Items.TOTEM_OF_UNDYING, 1));
                inv.setStack(20, new ItemStack(Items.WIND_CHARGE, 64));
                inv.setStack(21, new ItemStack(Items.WIND_CHARGE, 64));
                break;
        }

        // =========================================
        // DROP CHANCE FOR EQUIPPED GEAR (100% Drop)
        // =========================================
        bot.setEquipmentDropChance(EquipmentSlot.HEAD, 1.0f);
        bot.setEquipmentDropChance(EquipmentSlot.CHEST, 1.0f);
        bot.setEquipmentDropChance(EquipmentSlot.LEGS, 1.0f);
        bot.setEquipmentDropChance(EquipmentSlot.FEET, 1.0f);
        bot.setEquipmentDropChance(EquipmentSlot.MAINHAND, 1.0f);
        bot.setEquipmentDropChance(EquipmentSlot.OFFHAND, 1.0f);
    }

    // =========================================
    // HELPER METHODS
    // =========================================

    private static void applyEnchant(World world, ItemStack stack, RegistryKey<Enchantment> enchantKey, int level) {
        var registry = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        var entry = registry.getOrThrow(enchantKey);
        stack.addEnchantment(entry, level);
    }

    private static ItemStack getSplashPotion(World world, String potionName) {
        ItemStack potion = new ItemStack(Items.SPLASH_POTION);
        var registry = world.getRegistryManager().getOrThrow(RegistryKeys.POTION);
        var potionEntry = registry.getOrThrow(RegistryKey.of(RegistryKeys.POTION, Identifier.of("minecraft", potionName)));
        potion.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(potionEntry));
        return potion;
    }

    private static ItemStack getTool(World world, Item toolItem) {
        ItemStack tool = new ItemStack(toolItem);
        applyEnchant(world, tool, Enchantments.EFFICIENCY, 5);
        applyEnchant(world, tool, Enchantments.FORTUNE, 3);
        applyEnchant(world, tool, Enchantments.UNBREAKING, 3);
        applyEnchant(world, tool, Enchantments.MENDING, 1);
        return tool;
    }
}