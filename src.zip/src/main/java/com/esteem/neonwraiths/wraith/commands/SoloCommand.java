package com.esteem.neonwraiths.wraith.commands;

import com.esteem.neonwraiths.wraith.entities.WraithBot;
import com.esteem.neonwraiths.wraith.entities.ModEntities; // Exact Path
import com.esteem.neonwraiths.wraith.utils.FormationManager;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class SoloCommand {

    // =========================================
    // AUTO-COMPLETE LISTS (TAB SUGGESTIONS)
    // =========================================
    private static final SuggestionProvider<ServerCommandSource> SUGGEST_FORMATIONS = (context, builder) ->
            CommandSource.suggestMatching(List.of("line", "grid", "circle", "square", "spearhead", "wall", "random"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_PVP = (context, builder) ->
            CommandSource.suggestMatching(List.of("tank", "axe", "nethpot", "crystal", "anchor"), builder);

    private static final SuggestionProvider<ServerCommandSource> SUGGEST_ARMOR = (context, builder) ->
            CommandSource.suggestMatching(List.of("diamond", "netherite"), builder);


    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("solo")
                .requires(source -> net.minecraft.server.command.CommandManager.GAMEMASTERS_CHECK.allows(source.getPermissions()))

                // 🐣 SPAWN (CUSTOM NAME + MAX 5 LIMIT)
                .then(CommandManager.literal("spawn")
                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 5)) // 💥 Max 5 Bosses
                                .then(CommandManager.argument("botName", StringArgumentType.word()) // Custom Name Input
                                        .then(CommandManager.argument("pvp", StringArgumentType.word()).suggests(SUGGEST_PVP)
                                                .then(CommandManager.argument("armor", StringArgumentType.word()).suggests(SUGGEST_ARMOR)
                                                        .then(CommandManager.argument("formation", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS)
                                                                .executes(context -> {
                                                                    int count = IntegerArgumentType.getInteger(context, "count");
                                                                    String botName = StringArgumentType.getString(context, "botName");
                                                                    String pvp = StringArgumentType.getString(context, "pvp");
                                                                    String armor = StringArgumentType.getString(context, "armor");
                                                                    String formation = StringArgumentType.getString(context, "formation");
                                                                    return spawnBots(context.getSource(), count, botName, pvp, armor, formation);
                                                                })
                                                        )
                                                )
                                        )
                                )
                        )
                )

                // ⚔️ ATTACK COMMAND
                .then(CommandManager.literal("attack")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.ATTACK, "ATTACK", ""))
                        )
                )

                // 🛑 STOP COMMAND
                .then(CommandManager.literal("stop")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.STOP, "STOP", ""))
                )

                // 💤 IDLE / PASSIVE COMMAND
                .then(CommandManager.literal("idle")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "IDLE", ""))
                )
                .then(CommandManager.literal("passive")
                        .then(CommandManager.argument("state", BoolArgumentType.bool())
                                .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "PASSIVE", ""))
                        )
                )

                // 🛡️ DEFEND COMMAND
                .then(CommandManager.literal("defend")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.IDLE, "DEFEND", ""))
                )

                // 🏃‍♂️ FOLLOW COMMAND
                .then(CommandManager.literal("follow")
                        .then(CommandManager.argument("target", EntityArgumentType.player())
                                .executes(context -> executeMode(context.getSource(), EntityArgumentType.getPlayer(context, "target"), WraithBot.BotMode.FOLLOW, "FOLLOW", ""))
                        )
                )

                // ⭕ FORMATION COMMAND (Auto-Fill Fixed)
                .then(CommandManager.literal("formation")
                        .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.FORMATION, "FORMATION", "circle")) // Fallback for Auto-Complete
                        .then(CommandManager.argument("type", StringArgumentType.word()).suggests(SUGGEST_FORMATIONS)
                                .executes(context -> executeMode(context.getSource(), context.getSource().getPlayer(), WraithBot.BotMode.FORMATION, "FORMATION", StringArgumentType.getString(context, "type")))
                        )
                )
        );
    }

    // =========================================
    // 🧠 CENTRAL COMMAND EXECUTION (FSM LINKER)
    // =========================================
    private static int executeMode(ServerCommandSource source, ServerPlayerEntity targetPlayer, WraithBot.BotMode mode, String modeName, String formType) {
        if (targetPlayer == null) return 0;
        ServerPlayerEntity commander = source.getPlayer();
        if (commander == null) return 0;
        ServerWorld serverWorld = source.getWorld();

        Box radarBox = commander.getBoundingBox().expand(150.0D);

        // Filter ONLY Solo Tier (SOLO) Bots
        List<WraithBot> botsNearby = serverWorld.getEntitiesByClass(WraithBot.class, radarBox, bot -> bot.getTier() == WraithBot.Tier.SOLO);

        if (botsNearby.isEmpty()) {
            source.sendError(Text.literal("§c[SOLO] No SOLO Tier Boss found nearby!"));
            return 0;
        }

        int totalBots = botsNearby.size();
        int index = 0;

        // 💥 FINAL WIRING FIX: Sahi Malik aur Dushman
        for (WraithBot bot : botsNearby) {
            if (mode == WraithBot.BotMode.ATTACK) {
                bot.setBotMode(mode, commander, index, totalBots, formType);
                bot.setTarget(targetPlayer);
            } else if (mode == WraithBot.BotMode.FOLLOW) {
                bot.setBotMode(mode, targetPlayer, index, totalBots, formType);
            } else {
                bot.setBotMode(mode, commander, index, totalBots, formType);
            }
            index++;
        }

        String targetName = targetPlayer.getName().getString();
        if (mode == WraithBot.BotMode.ATTACK || mode == WraithBot.BotMode.FOLLOW) {
            source.sendFeedback(() -> Text.literal("§d[SOLO] " + totalBots + " Boss(es) switched to §l" + modeName + "§d on " + targetName + "!"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§d[SOLO] " + totalBots + " Boss(es) switched to §l" + modeName + (formType.isEmpty() ? "" : " (" + formType + ")")), false);
        }
        return 1;
    }

    // =========================================
    // SPAWN LOGIC (Custom Name + Max 5)
    // =========================================
    private static int spawnBots(ServerCommandSource source, int amount, String customName, String pvp, String armor, String formationType) {
        ServerWorld world = source.getWorld();
        ServerPlayerEntity player = source.getPlayer();

        if (player == null) return 0;

        float naturalYaw = player.getYaw();
        Vec3d centerPos = new Vec3d(
                Math.floor(source.getPosition().x) + 0.5,
                source.getPosition().y,
                Math.floor(source.getPosition().z) + 0.5
        );

        List<Vec3d> positions = FormationManager.generate(formationType, amount, centerPos, naturalYaw);

        for (int i = 0; i < amount; i++) {
            WraithBot bot = (WraithBot) ModEntities.WRAITH_BOT.create(world, net.minecraft.entity.SpawnReason.COMMAND);

            if (bot != null) {
                Vec3d targetPos = positions.get(i);
                double finalX = Math.floor(targetPos.x) + 0.5;
                double finalY = targetPos.y;
                double finalZ = Math.floor(targetPos.z) + 0.5;

                bot.refreshPositionAndAngles(finalX, finalY, finalZ, naturalYaw, 0.0F);
                bot.setHeadYaw(naturalYaw);
                bot.setBodyYaw(naturalYaw);

                // CUSTOM NAME INJECTION
                String finalName = amount > 1 ? customName + "_" + (i + 1) : customName;
                bot.setCustomName(Text.literal("§d§l" + finalName.replace("_", " ")));
                bot.setCustomNameVisible(true);

                bot.setTier(WraithBot.Tier.SOLO);
                com.esteem.neonwraiths.wraith.inventory.BotLoadout.equip(bot, pvp, armor);

                bot.setBotMode(WraithBot.BotMode.STOP, player, i, amount, formationType);

                world.spawnEntity(bot);

                source.getServer().getPlayerManager().broadcast(
                        Text.literal("§c⚠ WARNING: A SOLO Tier Boss (" + finalName.replace("_", " ") + ") has entered the world!"), false
                );
            }
        }

        source.sendFeedback(() -> Text.literal("§d[SOLO] Deployed " + amount + " World Leader(s) | Formation: " + formationType.toUpperCase()), false);
        return 1;
    }
}